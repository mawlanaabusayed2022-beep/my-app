# WebView Android App

1. `app/src/main/java/com/myapp/webview/MainActivity.kt` ফাইলে `APP_URL` এ আপনার সাইটের লিংক বসান।
2. অ্যাপের নাম বদলাতে `app/src/main/res/values/strings.xml` এডিট করুন।
3. GitHub-এ পুশ করুন, তারপর Actions ট্যাব → Build APK → নিচে Artifacts থেকে `app-debug-apk` নামান।
